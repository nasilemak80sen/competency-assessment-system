"""
app.py – RE Fraternity Competency Assessment System v3.0
Run with: streamlit run app.py
"""

from datetime import date, datetime

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from config import (
    APP_TITLE, DATABASE_URL, PRIMARY, SECONDARY,
    SCORE_COLS, REQ_COLS, GAP_COLS, COMP_TYPES,
    DEPARTMENTS, POSITIONS, CHAT_STATUS_OPTIONS, ASSESSMENT_LEVELS,
    GRADE_LABELS, HEATMAP_COLORSCALE,
)
from models import init_db, get_session, Personnel, Assessment
from data_loader import load_master_data
import db_ops
import analytics as an


# ─────────────────────────────────────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(page_title=APP_TITLE, page_icon="📊", layout="wide",
                    initial_sidebar_state="expanded")

st.markdown(f"""
<style>
.block-container {{ padding-top: 1.2rem; }}
h1, h2, h3 {{ color: {PRIMARY}; }}
.metric-box {{
    background:#F0F4F8; border-radius:10px; padding:14px 18px;
    border-left:5px solid {SECONDARY};
}}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────────────────────
# DB INIT
# ─────────────────────────────────────────────────────────────────────────────
@st.cache_resource
def get_engine():
    return init_db(DATABASE_URL)

engine = get_engine()

if "data_version" not in st.session_state:
    st.session_state.data_version = 0


def bump_version():
    st.session_state.data_version += 1


@st.cache_data
def load_wide_df(_version: int) -> pd.DataFrame:
    session = get_session(engine)
    try:
        df = db_ops.get_wide_dataframe(session)
    finally:
        session.close()
    if df.empty:
        return df
    df = an.add_category_averages(df)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# SIDEBAR NAVIGATION
# ─────────────────────────────────────────────────────────────────────────────
st.sidebar.title("📊 " + APP_TITLE)
page = st.sidebar.radio("Navigate", [
    "🏠 Dashboard Home",
    "👥 Personnel Directory",
    "🌡️ Competency Heatmap",
    "🔍 Individual Assessment",
    "🎯 Readiness & Gaps",
    "📈 Trends (Age vs Grade)",
    "⚙️ Admin: Import Data",
    "⚙️ Admin: Personnel CRUD",
    "⚙️ Admin: Assessment Entry",
])

df = load_wide_df(st.session_state.data_version)

if df.empty and not page.startswith("⚙️ Admin: Import"):
    st.warning("⚠️ No data in database yet. Go to **Admin: Import Data** to load the Excel master file.")


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: DASHBOARD HOME
# ═════════════════════════════════════════════════════════════════════════════
if page == "🏠 Dashboard Home":
    st.title("🏠 Dashboard Home")

    if df.empty:
        st.stop()

    session = get_session(engine)
    stats = db_ops.get_stats_overview(session)
    session.close()

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Total Personnel", stats["total"])
    with c2:
        assessed = df[SCORE_COLS].notna().any(axis=1).sum() if any(c in df.columns for c in SCORE_COLS) else 0
        st.metric("Assessed", int(assessed), f"{assessed/stats['total']*100:.0f}%" if stats['total'] else "")
    with c3:
        st.metric("Chat Status: Yes", stats["chat_yes"])
    with c4:
        st.metric("Chat Status: No (Pending)", stats["chat_no"])

    st.markdown("---")
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Position Distribution")
        pos = df["Staff Position"].value_counts().reset_index()
        pos.columns = ["Staff Position", "Count"]
        fig = px.bar(pos, x="Staff Position", y="Count", color="Staff Position",
                     color_discrete_sequence=px.colors.sequential.Teal)
        fig.update_layout(showlegend=False)
        st.plotly_chart(fig, use_container_width=True)

    with col2:
        st.subheader("Department Distribution")
        dept = df["Department"].value_counts().reset_index()
        dept.columns = ["Department", "Count"]
        fig = px.pie(dept, names="Department", values="Count", hole=0.4,
                     color_discrete_sequence=px.colors.sequential.RdBu)
        st.plotly_chart(fig, use_container_width=True)

    col3, col4 = st.columns(2)

    with col3:
        st.subheader("Chat Status Breakdown")
        cs = df["Chat Status"].fillna("No Need").value_counts().reset_index()
        cs.columns = ["Chat Status", "Count"]
        fig = px.bar(cs, x="Chat Status", y="Count", color="Chat Status",
                     color_discrete_map={"Yes": "#2E7D32", "No": "#C62828", "No Need": "#9E9E9E"})
        st.plotly_chart(fig, use_container_width=True)

    with col4:
        st.subheader("Assessment Completion by Department")
        comp = an.assessment_completion_by_dept(df)
        fig = px.bar(comp, x="Department", y="completion_pct", text="completion_pct",
                     color="completion_pct", color_continuous_scale="Tealgrn",
                     labels={"completion_pct": "Completion %"})
        fig.update_traces(texttemplate="%{text:.0f}%", textposition="outside")
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Grade (SG) Distribution")
    sg = df["SG"].value_counts().reset_index()
    sg.columns = ["SG", "Count"]
    sg["Label"] = sg["SG"].map(GRADE_LABELS).fillna(sg["SG"])
    fig = px.bar(sg.sort_values("SG"), x="SG", y="Count", text="Label",
                 color="Count", color_continuous_scale="Blues")
    st.plotly_chart(fig, use_container_width=True)


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: PERSONNEL DIRECTORY
# ═════════════════════════════════════════════════════════════════════════════
elif page == "👥 Personnel Directory":
    st.title("👥 Personnel Directory")

    if df.empty:
        st.stop()

    c1, c2, c3 = st.columns(3)
    with c1:
        f_dept = st.multiselect("Department", sorted(df["Department"].dropna().unique()))
    with c2:
        f_pos = st.multiselect("Position", sorted(df["Staff Position"].dropna().unique()))
    with c3:
        f_chat = st.multiselect("Chat Status", CHAT_STATUS_OPTIONS)

    search = st.text_input("🔎 Search by Name or Staff ID")

    fdf = df.copy()
    if f_dept:
        fdf = fdf[fdf["Department"].isin(f_dept)]
    if f_pos:
        fdf = fdf[fdf["Staff Position"].isin(f_pos)]
    if f_chat:
        fdf = fdf[fdf["Chat Status"].isin(f_chat)]
    if search:
        mask = fdf["Name"].str.contains(search, case=False, na=False) | \
               fdf["Staff ID"].astype(str).str.contains(search, case=False, na=False)
        fdf = fdf[mask]

    st.caption(f"Showing {len(fdf)} of {len(df)} personnel")
    display_cols = ["Name", "Staff ID", "Staff Position", "SG", "Department",
                    "Age", "Chat Status", "Overall_avg"]
    display_cols = [c for c in display_cols if c in fdf.columns]
    show = fdf[display_cols].rename(columns={"Overall_avg": "Avg Score"})
    if "Avg Score" in show.columns:
        show["Avg Score"] = show["Avg Score"].round(2)
    st.dataframe(show, use_container_width=True, hide_index=True)

    # CSV export
    csv = show.to_csv(index=False).encode()
    st.download_button("⬇️ Download as CSV", csv, "personnel_directory.csv", "text/csv")


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: COMPETENCY HEATMAP
# ═════════════════════════════════════════════════════════════════════════════
elif page == "🌡️ Competency Heatmap":
    st.title("🌡️ Competency Heatmap")

    if df.empty:
        st.stop()

    c1, c2, c3 = st.columns(3)
    with c1:
        f_dept = st.multiselect("Department", sorted(df["Department"].dropna().unique()), key="hm_dept")
    with c2:
        f_pos = st.multiselect("Position", sorted(df["Staff Position"].dropna().unique()), key="hm_pos")
    with c3:
        f_type = st.multiselect("Competency Type", list(COMP_TYPES.keys()),
                                default=list(COMP_TYPES.keys()), key="hm_type")

    fdf = df.copy()
    if f_dept:
        fdf = fdf[fdf["Department"].isin(f_dept)]
    if f_pos:
        fdf = fdf[fdf["Staff Position"].isin(f_pos)]

    value_cols = []
    for t in f_type:
        value_cols += [c for c in COMP_TYPES[t]["cols"] if c in fdf.columns]

    if not value_cols:
        st.info("Select at least one competency type.")
        st.stop()

    mat = an.build_heatmap_matrix(fdf, value_cols)

    if mat.empty:
        st.warning("No assessed personnel match these filters.")
        st.stop()

    st.caption(f"Showing {len(mat)} assessed personnel × {len(value_cols)} competencies")

    fig = go.Figure(data=go.Heatmap(
        z=mat.values,
        x=mat.columns,
        y=mat.index,
        colorscale=HEATMAP_COLORSCALE,
        zmin=0, zmax=5,
        colorbar=dict(title="Score"),
        hovertemplate="Person: %{y}<br>Competency: %{x}<br>Score: %{z}<extra></extra>"
    ))
    fig.update_layout(height=max(400, 20 * len(mat)), xaxis_nticks=len(value_cols))
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Summary Statistics")
    s1, s2, s3, s4 = st.columns(4)
    flat = mat.values.flatten()
    flat = flat[~np.isnan(flat)]
    with s1:
        st.metric("Average Score", f"{flat.mean():.2f}" if len(flat) else "N/A")
    with s2:
        st.metric("High Performers (≥4)", int((flat >= 4).sum()))
    with s3:
        st.metric("Needs Development (≤2)", int((flat <= 2).sum()))
    with s4:
        st.metric("Total Data Points", len(flat))


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: INDIVIDUAL ASSESSMENT
# ═════════════════════════════════════════════════════════════════════════════
elif page == "🔍 Individual Assessment":
    st.title("🔍 Individual Assessment")

    if df.empty:
        st.stop()

    names = sorted(df["Name"].dropna().unique())
    selected = st.selectbox("Select Personnel", names)

    person_row = df[df["Name"] == selected].iloc[0]

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.metric("Position / Grade", f"{person_row.get('Staff Position')} ({person_row.get('SG')})")
    with c2:
        st.metric("Department", person_row.get("Department"))
    with c3:
        st.metric("Age", int(person_row["Age"]) if pd.notna(person_row.get("Age")) else "N/A")
    with c4:
        st.metric("Chat Status", person_row.get("Chat Status"))

    st.markdown("---")

    gap_df = an.gap_analysis_individual(person_row)

    if gap_df.empty:
        st.info("No assessment scores recorded yet for this person.")
    else:
        col1, col2 = st.columns([1, 1])

        with col1:
            st.subheader("Actual vs Target")
            fig = go.Figure()
            fig.add_trace(go.Bar(x=gap_df["Competency"], y=gap_df["Actual"], name="Actual",
                                 marker_color=SECONDARY))
            fig.add_trace(go.Scatter(x=gap_df["Competency"], y=gap_df["Target"], name="Target",
                                     mode="markers", marker=dict(color="red", size=8, symbol="diamond")))
            fig.update_layout(yaxis_range=[0, 5], height=400)
            st.plotly_chart(fig, use_container_width=True)

        with col2:
            st.subheader("Category Radar")
            cat_vals = []
            cat_names = []
            for ctype, info in COMP_TYPES.items():
                avg_col = f"{ctype}_avg"
                if avg_col in person_row.index and pd.notna(person_row[avg_col]):
                    cat_vals.append(person_row[avg_col])
                    cat_names.append(info["label"])
            if cat_vals:
                fig2 = go.Figure(data=go.Scatterpolar(
                    r=cat_vals + [cat_vals[0]],
                    theta=cat_names + [cat_names[0]],
                    fill="toself", line_color=PRIMARY
                ))
                fig2.update_layout(polar=dict(radialaxis=dict(visible=True, range=[0, 5])),
                                  height=400, showlegend=False)
                st.plotly_chart(fig2, use_container_width=True)

        st.subheader("Gap Analysis Detail")
        def _color_status(val):
            colors = {"Met": "background-color:#C8E6C9",
                     "Minor Gap": "background-color:#FFF9C4",
                     "Major Gap": "background-color:#FFCDD2"}
            return colors.get(val, "")
        styled = gap_df.style.map(_color_status, subset=["Status"])
        st.dataframe(styled, use_container_width=True, hide_index=True)

        # Gap counts
        n_met = (gap_df["Status"] == "Met").sum()
        n_minor = (gap_df["Status"] == "Minor Gap").sum()
        n_major = (gap_df["Status"] == "Major Gap").sum()
        g1, g2, g3 = st.columns(3)
        g1.metric("✅ Met Target", int(n_met))
        g2.metric("🟡 Minor Gaps", int(n_minor))
        g3.metric("🔴 Major Gaps", int(n_major))

    # ── Trend history ───────────────────────────────────────────────────────
    st.markdown("---")
    st.subheader("Assessment History / Trend")
    session = get_session(engine)
    pid = int(person_row["id"])
    hist = db_ops.get_assessment_history(session, pid)
    session.close()

    if hist.empty:
        st.info("No historical assessment trend data available (only one assessment on record).")
    else:
        trend = hist.groupby(["date", "competency_type"])["actual_score"].mean().reset_index()
        fig3 = px.line(trend, x="date", y="actual_score", color="competency_type",
                       markers=True, labels={"actual_score": "Avg Score", "date": "Assessment Date"})
        st.plotly_chart(fig3, use_container_width=True)


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: READINESS & GAPS
# ═════════════════════════════════════════════════════════════════════════════
elif page == "🎯 Readiness & Gaps":
    st.title("🎯 Readiness & Gaps Analysis")

    if df.empty:
        st.stop()

    tab1, tab2 = st.tabs(["Readiness Tiers", "Gap Status"])

    with tab1:
        ready_df = an.readiness_table(df)

        c1, c2, c3, c4 = st.columns(4)
        for col, tier in zip([c1, c2, c3, c4],
                             ["Tier 1 (<50%)", "Tier 2 (50-80%)", "Tier 3 (80-99%)", "Tier 4 (≥100%)"]):
            col.metric(tier, int((ready_df["Readiness Tier"] == tier).sum()))

        st.markdown("---")

        fig = px.histogram(ready_df.dropna(subset=["Achievement %"]),
                           x="SG", color="Readiness Tier", barmode="stack",
                           category_orders={"SG": sorted(ready_df["SG"].dropna().unique())},
                           color_discrete_sequence=px.colors.sequential.RdYlGn)
        fig.update_layout(title="Readiness Tier by Grade (SG)")
        st.plotly_chart(fig, use_container_width=True)

        st.subheader("Personnel Ready for Next Assessment")
        ready_only = ready_df[ready_df["Ready for Assessment"] == "Ready"]
        st.dataframe(ready_only.sort_values("Achievement %", ascending=False),
                     use_container_width=True, hide_index=True)

        st.subheader("Full Readiness Table")
        st.dataframe(ready_df, use_container_width=True, hide_index=True)

    with tab2:
        gap_df = an.gap_summary(df)
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("No Gap", int((gap_df["Gap Status"] == "No Gap").sum()))
        c2.metric("1 Gap", int((gap_df["Gap Status"] == "1 Gap").sum()))
        c3.metric(">1 Gap", int((gap_df["Gap Status"] == ">1 Gap").sum()))
        c4.metric("Not Assessed", int((gap_df["Gap Status"] == "Not Assessed").sum()))

        fig = px.pie(gap_df, names="Gap Status", hole=0.4,
                     color="Gap Status",
                     color_discrete_map={"No Gap": "#2E7D32", "1 Gap": "#FDD835",
                                        ">1 Gap": "#C62828", "Not Assessed": "#9E9E9E"})
        st.plotly_chart(fig, use_container_width=True)

        st.dataframe(gap_df, use_container_width=True, hide_index=True)


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: TRENDS (AGE VS GRADE SCATTER)
# ═════════════════════════════════════════════════════════════════════════════
elif page == "📈 Trends (Age vs Grade)":
    st.title("📈 Age vs Grade Analysis")

    if df.empty:
        st.stop()

    c1, c2 = st.columns(2)
    with c1:
        f_dept = st.multiselect("Filter by Department", sorted(df["Department"].dropna().unique()), key="sc_dept")
    with c2:
        f_pos = st.multiselect("Filter by Position", sorted(df["Staff Position"].dropna().unique()), key="sc_pos")

    fdf = df.copy()
    if f_dept:
        fdf = fdf[fdf["Department"].isin(f_dept)]
    if f_pos:
        fdf = fdf[fdf["Staff Position"].isin(f_pos)]

    scatter_df = an.scatter_age_vs_grade(fdf)

    if scatter_df.empty:
        st.warning("No data available for the selected filters.")
        st.stop()

    color_col = "Overall_avg" if "Overall_avg" in scatter_df.columns else None

    fig = px.scatter(
        scatter_df, x="Age", y="SG", color=color_col, hover_data=["Name", "Staff Position", "Department"],
        category_orders={"SG": sorted(df["SG"].dropna().unique())},
        color_continuous_scale="Tealgrn", title="Age vs Salary Grade (colored by Overall Avg Score)"
    )
    fig.update_layout(height=600)
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Years in PET vs Overall Score")
    if "Years in PET" in fdf.columns and "Overall_avg" in fdf.columns:
        fig2 = px.scatter(fdf, x="Years in PET", y="Overall_avg", color="Staff Position",
                          hover_data=["Name"], trendline="ols")
        st.plotly_chart(fig2, use_container_width=True)


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: ADMIN - IMPORT DATA
# ═════════════════════════════════════════════════════════════════════════════
elif page == "⚙️ Admin: Import Data":
    st.title("⚙️ Admin: Import Data from Excel")

    st.info("""
    Upload the RE Fraternity Master Excel file (the 'All' tab will be used).
    The importer reads:
    - Header row 3, data from row 4 onward
    - Personnel demographics & employment info
    - Competency scores (B1-B12, K1-K5, P1-P5, E1-E2) + targets (R-...) + gaps (G--...)
    - Summary scores (Staff/Principal/Custodian Base/Keys/Pacing/Emerging/CTI)

    **Re-importing updates existing records** (matched by Staff ID) and adds new assessments
    if the assessment date differs from any existing record.
    """)

    uploaded = st.file_uploader("Upload Excel file (.xlsx)", type=["xlsx"])

    if uploaded:
        try:
            tmp_path = "/tmp/_uploaded_master.xlsx"
            with open(tmp_path, "wb") as f:
                f.write(uploaded.getbuffer())

            raw_df = load_master_data(tmp_path)
            st.success(f"✅ Loaded {len(raw_df)} personnel records from '{uploaded.name}'")

            st.subheader("Preview (first 10 rows)")
            preview_cols = ["Name", "Staff ID", "Staff Position", "SG", "Department",
                            "Chat Status", "B1", "K1", "P1", "E1"]
            preview_cols = [c for c in preview_cols if c in raw_df.columns]
            st.dataframe(raw_df[preview_cols].head(10), use_container_width=True)

            if st.button("✅ Confirm Import to Database", type="primary"):
                session = get_session(engine)
                with st.spinner("Importing... this may take a minute for 200+ records"):
                    result = db_ops.bulk_import_from_df(session, raw_df)
                session.close()
                st.success(f"Import complete — Added: {result['added']}, "
                          f"Updated: {result['updated']}, Errors: {result['errors']}")
                bump_version()
                st.cache_data.clear()
                st.rerun()

        except Exception as e:
            st.error(f"❌ Error reading file: {e}")
            st.exception(e)

    st.markdown("---")
    st.subheader("Current Database Status")
    session = get_session(engine)
    n_personnel = session.query(Personnel).filter_by(is_deleted=False).count()
    n_assessments = session.query(Assessment).count()
    session.close()
    c1, c2 = st.columns(2)
    c1.metric("Personnel Records", n_personnel)
    c2.metric("Assessment Records", n_assessments)

    if st.button("🗑️ Reset Database (delete all data)"):
        if st.session_state.get("confirm_reset"):
            from models import Base
            Base.metadata.drop_all(engine)
            Base.metadata.create_all(engine)
            bump_version()
            st.cache_data.clear()
            st.success("Database reset.")
            st.session_state.confirm_reset = False
            st.rerun()
        else:
            st.session_state.confirm_reset = True
            st.warning("Click again to confirm reset. This deletes ALL data permanently.")


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: ADMIN - PERSONNEL CRUD
# ═════════════════════════════════════════════════════════════════════════════
elif page == "⚙️ Admin: Personnel CRUD":
    st.title("⚙️ Admin: Personnel CRUD")

    tab1, tab2, tab3 = st.tabs(["➕ Add", "✏️ Edit", "🗑️ Delete"])

    with tab1:
        with st.form("add_form"):
            c1, c2, c3 = st.columns(3)
            with c1:
                name = st.text_input("Name *")
                staff_id = st.text_input("Staff ID *")
                email = st.text_input("Email")
            with c2:
                gender = st.selectbox("Gender", ["M", "F"])
                age = st.number_input("Age", 18, 70, 30)
                nationality = st.text_input("Nationality", "Malaysia")
            with c3:
                department = st.selectbox("Department", DEPARTMENTS[:-1])
                position = st.selectbox("Staff Position", POSITIONS[:-1])
                chat_status = st.selectbox("Chat Status", CHAT_STATUS_OPTIONS)

            if st.form_submit_button("Add Personnel", type="primary"):
                if not name or not staff_id:
                    st.error("Name and Staff ID are required.")
                else:
                    session = get_session(engine)
                    ok, msg, pid = db_ops.add_personnel(session, {
                        "name": name, "staff_id": staff_id, "email": email,
                        "gender": gender, "age": age, "nationality": nationality,
                        "department": department, "staff_position": position,
                        "chat_status": chat_status,
                    })
                    session.close()
                    if ok:
                        st.success(msg)
                        bump_version()
                        st.cache_data.clear()
                    else:
                        st.error(msg)

    with tab2:
        if df.empty:
            st.info("No personnel to edit.")
        else:
            names = sorted(df["Name"].dropna().unique())
            sel = st.selectbox("Select person", names, key="edit_sel")
            row = df[df["Name"] == sel].iloc[0]
            pid = int(row["id"])

            with st.form("edit_form"):
                c1, c2, c3 = st.columns(3)
                with c1:
                    name = st.text_input("Name", row["Name"])
                    age = st.number_input("Age", 18, 70, int(row["Age"]) if pd.notna(row["Age"]) else 30)
                with c2:
                    department = st.text_input("Department", row.get("Department") or "")
                    position = st.text_input("Staff Position", row.get("Staff Position") or "")
                with c3:
                    sg = st.text_input("SG (Grade)", row.get("SG") or "")
                    chat_status = st.selectbox("Chat Status", CHAT_STATUS_OPTIONS,
                                              index=CHAT_STATUS_OPTIONS.index(row["Chat Status"])
                                              if row["Chat Status"] in CHAT_STATUS_OPTIONS else 2)

                if st.form_submit_button("Update", type="primary"):
                    session = get_session(engine)
                    ok, msg = db_ops.update_personnel(session, pid, {
                        "name": name, "age": age, "department": department,
                        "staff_position": position, "sg": sg, "chat_status": chat_status,
                    })
                    session.close()
                    if ok:
                        st.success(msg)
                        bump_version()
                        st.cache_data.clear()
                        st.rerun()
                    else:
                        st.error(msg)

    with tab3:
        if df.empty:
            st.info("No personnel to delete.")
        else:
            names = sorted(df["Name"].dropna().unique())
            sel = st.selectbox("Select person to delete", names, key="del_sel")
            row = df[df["Name"] == sel].iloc[0]
            pid = int(row["id"])

            st.warning(f"⚠️ This will soft-delete **{sel}** (Staff ID: {row['Staff ID']})")
            if st.button("Confirm Delete", type="primary"):
                session = get_session(engine)
                ok, msg = db_ops.delete_personnel(session, pid)
                session.close()
                if ok:
                    st.success(msg)
                    bump_version()
                    st.cache_data.clear()
                    st.rerun()
                else:
                    st.error(msg)


# ═════════════════════════════════════════════════════════════════════════════
# PAGE: ADMIN - ASSESSMENT ENTRY
# ═════════════════════════════════════════════════════════════════════════════
elif page == "⚙️ Admin: Assessment Entry":
    st.title("⚙️ Admin: New Assessment Entry")

    if df.empty:
        st.info("No personnel available. Import data first.")
        st.stop()

    names = sorted(df["Name"].dropna().unique())
    sel = st.selectbox("Select Personnel", names)
    row = df[df["Name"] == sel].iloc[0]
    pid = int(row["id"])

    st.markdown(f"**{sel}** — {row.get('Staff Position')} ({row.get('SG')}) — {row.get('Department')}")

    with st.form("assessment_form"):
        c1, c2 = st.columns(2)
        with c1:
            adate = st.date_input("Assessment Date", value=date.today())
            level = st.selectbox("Assessment Level", ASSESSMENT_LEVELS)
        with c2:
            assessor1 = st.text_input("Assessor 1")
            supervisor = st.text_input("Supervisor")

        st.markdown("### Competency Scores (Actual / Target — leave Target as previous if unsure)")

        score_inputs = {}
        for ctype, info in COMP_TYPES.items():
            with st.expander(f"{info['label']} ({ctype})", expanded=(ctype == "B")):
                for code in info["cols"]:
                    prev_actual = row.get(code)
                    prev_req = row.get(f"R-{code}")
                    cc1, cc2 = st.columns(2)
                    with cc1:
                        actual = st.number_input(
                            f"{code} Actual", 0.0, 5.0,
                            float(prev_actual) if pd.notna(prev_actual) else 0.0,
                            step=0.5, key=f"act_{code}"
                        )
                    with cc2:
                        req = st.number_input(
                            f"{code} Target", 0.0, 5.0,
                            float(prev_req) if pd.notna(prev_req) else 3.0,
                            step=0.5, key=f"req_{code}"
                        )
                    score_inputs[code] = {"actual": actual, "req": req, "gap": round(actual - req, 2)}

        submitted = st.form_submit_button("💾 Save Assessment", type="primary")

        if submitted:
            session = get_session(engine)
            ok, msg, aid = db_ops.add_assessment(session, pid, {
                "assessment_date": adate, "assessment_level": level,
                "assessor1": assessor1, "supervisor": supervisor,
            })
            if ok:
                ok2, msg2 = db_ops.add_competency_scores(session, aid, pid, score_inputs)
                session.close()
                if ok2:
                    st.success(f"✅ Assessment saved for {sel} on {adate}")
                    bump_version()
                    st.cache_data.clear()
                else:
                    st.error(msg2)
            else:
                session.close()
                st.error(msg)


# ─────────────────────────────────────────────────────────────────────────────
st.sidebar.markdown("---")
st.sidebar.caption(f"DB: `{DATABASE_URL}` · v3.0 · {datetime.now().strftime('%Y-%m-%d')}")
